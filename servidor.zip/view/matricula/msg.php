﻿<p>&nbsp;</p>
<p align="center"><strong> Seus dados foram alterados com sucesso, observe sua caixa de e-mail, pois os dados alterados foram enviados.</strong></p>
<p align="center"><img src="img/logoCaxiasBranco.jpg" width="202" height="41" /></p>

