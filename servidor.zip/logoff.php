<?php
require_once("controles/index.php");
Processo('logoff');
?>
