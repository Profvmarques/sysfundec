<?php
require_once('conexao.php');
require_once('logs.php');

//Sempre primeira letra maiúscula
class Turma {

    //Atributos da classe
    private $idturma;
    private $siglacurso;
    private $sigladisciplina;
    private $idmatriz;
    private $matriculaprofessor;
    private $grade_horario;
    private $idperiodoletivo;
    private $tiposituacao;
    private $qtdetotal;
   
    //Método
    public function Incluir($idturma,$siglacurso,$sigladisciplina,$idmatriz,
            $matriculaprofessor,$grade_horario,$idperiodoletivo,$tiposituacao,
            $qtdetotal) {
        $insert = 'insert into turma(idturma,siglacurso,sigladisciplina,idmatriz,
            matriculaprofessor,grade_horario,idperiodoletivo,tiposituacao,
            qtdetotal) values("'.$idturma.'","'.$siglacurso.'","'.$sigladisciplina.'","'.$idmatriz.'",
                "'.$matriculaprofessor.'","'.$grade_horario.'","'.$idperiodoletivo.'","'.$tiposituacao.'",
                    ,"'.$qtdetotal.'")';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($insert);

        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $insert, 'turma', 'Inserir');
    }

    
 
    //consultar
    public function consultar($sql) {
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($sql);
        $this->Linha = @mysql_num_rows($Acesso->result);
        $this->Result = $Acesso->result;
    }

    
       //Editar
    public function Alterar($idturma,$siglacurso,$sigladisciplina,$idmatriz,
            $matriculaprofessor,$grade_horario,$idperiodoletivo,$tiposituacao,
            $qtdetotal){
        $update = 'update turma set idturma="'.$idturma.'",siglacurso="'.$siglacurso.'",
            sigladisciplina="'.$sigladisciplina.'",idmatriz="'.$idmatriz.'"
            matriculaprofessor="'.$matriculaprofessor.'",grade_horario="'.$grade_horario.'",
                ,idperiodoletivo="'.$idperiodoletivo.'",tiposituacao="'.$tiposituacao.'" 
                    where idmatriz="'.$idmatriz.'"';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($update);
        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $update, 'turma', 'Alterar');
    }

}

?>