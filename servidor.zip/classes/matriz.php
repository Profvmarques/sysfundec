<?php
require_once('conexao.php');
require_once('logs.php');

class Matriz {

    //Atributos da classe
    private $idmatriz;
    private $siglacurso;
    private $data_vigencia;
   
    //Método
    public function Incluir($siglacurso,$data_vigencia) {
        $insert = 'insert into matriz(siglacurso,data_vigencia) values("'.$siglacurso.'","'.$data_vigencia.'")';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($insert);

        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $insert, 'matriz', 'Inserir');
    }

    
 
    //consultar
    public function consultar($sql) {
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($sql);
        $this->Linha = @mysql_num_rows($Acesso->result);
        $this->Result = $Acesso->result;
    }

    
       //Editar
    public function Alterar($idmatriz,$siglacurso,$data_vigencia){
        $update = 'update matriz set siglacurso="'.$descricao.'",data_vigencia="'.$data_vigencia.'"
            where idmatriz="'.$idmatriz.'"';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($update);
        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $update, 'matriz', 'Alterar');
    }

}

?>