<?php
require_once('conexao.php');
require_once('logs.php');

class Usuarios {

    //Atributos da classe
    private $idusuarios;
    private $login;
    private $senha;
    private $idperfil;
    private $dtreg;

    //Método
    public function Incluir($login,$senha,$idperfil) {
       $insert = 'insert into usuarios(login,senha,situacao,idperfil,dtreg)values("'.$login.'","'.$senha.'","SIM","'.$idperfil.'","'.date('Y-m-d H:i:s').'")';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($insert); 

        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $insert, 'usuarios', 'Inserir');
        
        $this->consultar("select max(idusuarios) as idU from usuarios");
        $rs=  $this->Result;
        $idusuarios=mysql_result($rs,0,'idU');
        return $idusuarios;
    }

    
 
    //consultar
    public function consultar($sql) {
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($sql);
        $this->Linha = @mysql_num_rows($Acesso->result);
        $this->Result = $Acesso->result;
    }

    
       //Editar
    public function Alterar($idusuarios,$login,$senha,$idperfil){
        $update = ' update usuarios set login="'.$login.'",senha="'.base64_encode($senha).'",
            idperfil="'.$idperfil.'" where idusuarios="'.$idusuarios.'"';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($update);
        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $update, 'usuarios', 'Alterar');
    }
    
      public function alteraSenha($idusuarios,$senha){
        $update = 'update usuarios set senha="'.base64_encode($senha).'" where idusuarios="'.$idusuarios.'"';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($update);
        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $update, 'usuarios', 'alterar senha');
    }

}

?>