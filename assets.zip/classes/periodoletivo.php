<?php
require_once('conexao.php');
require_once('logs.php');

//Sempre primeira letra maiúscula
class PeriodoLetivo {

    //Atributos da classe
    private $idperiododletivo;
    private $siglacurso;
    private $siglaperiodo;
    private $data_inicio;
    private $data_fim;
    private $dtreg;
   
    //Método
    public function Incluir($siglacurso,$siglaperiodo,$data_inicio,$data_fim) {
        
        $insert = 'insert into periodoletivo(siglacurso,siglaperiodo,data_inicio,data_fim,dtreg) 
            values("'.$siglacurso.'","'.$siglaperiodo.'","'.$data_inicio.'","'.$data_fim.'","'.date('Y-m-d H:i:s').'")';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($insert);

        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $insert, 'periodoletivo', 'Inserir');
    }

    
 
    //consultar
    public function consultar($sql) {
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($sql);
        $this->Linha = @mysql_num_rows($Acesso->result);
        $this->Result = $Acesso->result;
    }

    
       //Editar
    public function Alterar($idperiodoletivo,$siglacurso,$siglaperiodo,$data_inicio,$data_fim){
         $update = 'update periodoletivo set siglacurso="'.$siglacurso.'",
            siglaperiodo="'.$siglaperiodo.'",data_inicio="'.$data_inicio.'"
            ,data_fim="'.$data_fim.'" where idperiodoletivo="'.$idperiodoletivo.'"';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($update);
        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $update, 'periodoletivo', 'Alterar');
    }

}

?>