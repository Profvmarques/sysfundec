<?php
require_once('conexao.php');
require_once('logs.php');

class Disciplinas {

    //Atributos da classe
    private $sigladisciplina;
    private $descricao;
   
    //Método
    public function Incluir($sigladisciplina,$descricao) {
        $insert = 'insert into disciplinas(sigladisciplina,descricao) values("'.$sigladisciplina.'","'.$descricao.'")';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($insert);

        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $insert, 'disciplinas', 'Inserir');
    }

    
 
    //consultar
    public function consultar($sql) {
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($sql);
        $this->Linha = @mysql_num_rows($Acesso->result);
        $this->Result = $Acesso->result;
    }

    
       //Editar
    public function Alterar($sigladisciplina,$descricao){
        $update = 'update disciplinas set sigladisciplina="'.$sigladisciplina.'",descricao="'.$descricao.'"
            where sigladisciplina="'.$sigladisciplina.'"';
        $Acesso = new Acesso();
        $Acesso->Conexao();
        $Acesso->Query($update);
        $Logs = new Logs();
        $Logs->Incluir($_SESSION['idusuarios'], $update, 'disciplinas', 'Alterar');
    }

}

?>