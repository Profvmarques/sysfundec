<?php
session_start();

require_once('classes/adm_acesso_usuario.php');
require_once('classes/util.php');

/* Function Processos */
global $Adm_acesso_usuario;

function Processo($Processo) {


    /* Switch processos */
    switch ($Processo) {
        /* login de identificação */
        case 'login':
            /* Atributos Globais */
            $util = new Util(); 
            $adm_acesso_usuario = new Adm_acesso_usuario();

            if ($_POST['ok'] == 'true') {
                 $sql = "select * from usuarios u inner join pessoas p
                             on(u.idusuarios=p.idusuarios) where u.login='" . $_POST['login'] . "' and u.senha='" .base64_encode($_POST['senha']) . "'";
                $adm_acesso_usuario->consultar($sql);
                $rs = $adm_acesso_usuario->Result;
                $linha = $adm_acesso_usuario->Linha;
                if ($linha > 0) {
                    $_SESSION['idusuarios'] = mysql_result($rs, 0, 'u.idusuarios');
                    $_SESSION['idperfil'] = mysql_result($rs, 0, 'u.idperfil');
                    if(mysql_result($rs, 0, 'p.foto')!=''){
                        
                      $_SESSION['foto'] = mysql_result($rs, 0, 'p.foto');  
                    }else{
                     $_SESSION['foto'] ="sem_foto.jpg";   
                    }
                    $_SESSION['login'] = mysql_result($rs, 0, 'u.login');                    
                    $_SESSION['horalogado'] = "Logado em " . date('H:i');
                    $util->redirecionamentopage("default.php?pg=view/ocorrencias/ocorrencias.php&form=Ocorrências que merecem atenção");
                } else {
                    $util->msgbox("Login ou senha errado!");
                }
            }
            break;
            case 'logoff':
              $util = new Util();
              session_destroy();
              $util->redirecionamentopage("index.php");
                
            break;    
    }
}

?>