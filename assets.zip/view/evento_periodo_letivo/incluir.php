﻿<?php
require_once('controles/curso.php');
Processo('incluir');
?>
<form class="form-horizontal" id="form" name="form" method="post">
  <table width="1010">
    <tr>
      <td width="725">&nbsp;</td>
      <td width="273"><a href="default.php?pg=view/curso/consulta.php&amp;form=Consulta de Curso"><strong><i class="icon-search"> Consultar Evento do Período Letivo </i></strong></a> </td>
    </tr>
  </table>
  <table width="397" border="0">
    <tr>
      <td width="169" class="control-group"><label class="control-label">PERÍODO LETIVO </label></td>
      <td width="218">&nbsp;</td>
    </tr>
    <tr>
      <td width="169" class="control-group"><label class="control-label">DATA</label></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="control-group">TIPO DE EVENTO</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="control-group"><label class="control-label">EVENTO</label></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <div class="form-actions">
                                  <button type="button" class="btn btn-primary" onClick="validar(document.form);">
                              </i> SALVAR</button>
                                  <button type="button" class="btn" >CANCELAR</button>
                               <input name="ok" type="hidden" id="ok"/></div>
</form>