﻿<?php
require_once('../../controles/relatorio.php');
Processo('imprimirFicha');
ob_start();  //inicia o buffer	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>Relat&oacute;rio dos materiais comparativo de controle pr&oacute;prio sintetizado</title>
</head>

<body>
<p align="center"><img src="../../img/logorj.jpg" width="65" height="84" /></p>
<p align="center"><strong>GOVERNO DO ESTADO DO RIO DE JANEIRO</strong><br />
  <strong>SECRETARIA DE ESTADO DE CIÊNCIA E TECNOLOGIA</strong><br />
  <strong>FUNDAÇÃO DE APOIO À ESCOLA TÉCNICA</strong><strong> </strong><br />
  <strong>FACULDADES DE EDUCAÇÃO TECNOLÓGICA DO ESTADO DO RIO DE JANEIRO –  DUQUE DE CAXIAS</strong><br />
  <strong>PARECER DE RECONHECIMENTO CEE/RJ Nº 335/2013 DOERJ 28/05/2013</strong><br />
  <strong> RESOLUÇÃO CNE/CP Nº 1, DE  28/05/2013</strong></p>
<br />
<table width="871">
  <tbody>
    <tr>
      <td width="50">NOME:</td>
      <td width="340"><b><?php echo utf8_encode(mysql_result($r,0,'p.nome')); ?></b></td>
      <td width="57">SEXO:</td>
      <td width="86"><b><?php echo mysql_result($r,0,'p.sexo'); ?></b></td>
      <td width="191">DATA DE NASCIMENTO . </td>
      <td width="119"><b><?php echo mysql_result($r,0,'dtnasc'); ?></b></td>
    </tr>
  </tbody>
</table>
<table width="852">
  <tbody>
    <tr>
      <td width="161">NACIONALIDADE : </td>
      <td width="679"><b><?php echo mysql_result($r,0,'p.nacionalidade'); ?></b></td>
    </tr>
  </tbody>
</table>
<table width="725">
  <tbody>
    <tr>
      <td width="102">ENDEREÇO :</td>
      <td width="611"><?php echo mysql_result($r,0,'p.endereco'); ?></td>
    </tr>
  </tbody>
</table>
<table width="891">
  <tbody>
    <tr>
      <td width="105">TELEFONE:</td>
      <td width="139"><b><?php echo utf8_encode(mysql_result($r,0,'p.telefone')); ?></b></td>
      <td width="88">CELULAR : </td>
      <td width="179"><b><?php echo utf8_encode(mysql_result($r,0,'p.celular')); ?></b></td>
      <td width="62">E-MAIL :</td>
      <td width="290"><b><?php echo utf8_encode(mysql_result($r,0,'p.email')); ?></b></td>
    </tr>
  </tbody>
</table>
<table width="1059">
  <tbody>
    <tr>
      <td width="114">BAIRRO : </td>
      <td width="279"><b><?php echo mysql_result($r,0,'p.bairro'); ?></b></td>
      <td width="129">MUNÍCIPIO :</td>
      <td width="291"><b><?php echo mysql_result($r,0,'p.cidade'); ?></b></td>
      <td width="117">CEP : <b><?php echo mysql_result($r,0,'p.cep'); ?></b></td>
      <td width="101">UF : <b><?php echo mysql_result($r,0,'p.uf'); ?></b></td>
    </tr>
    <tr>
      <td width="114">ESTADO CIVIL </td>
      <td width="279"><b><?php echo mysql_result($r,0,'ec.descricao'); ?></b></td>
      <td width="129">ETNIA / COR </td>
      <td width="291"><b><?php echo mysql_result($r,0,'e.descricao'); ?></b></td>
      <td width="117">&nbsp;</td>
      <td width="101">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="6">NECESSIDADES ESPECIAIS </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>LOGIN : </td>
      <td><b><?php echo mysql_result($r,0,'u.login'); ?></b></td>
      <td>SENHA  : </td>
      <td>&nbsp;</td>
      <td>xxxxxxxx</td>
      <td>xxxxxxxx</td>
    </tr>
  </tbody>
</table>
<br />
<table width="1059">
  <tbody>
    <?php for($i=0;$i<$ln;$i++){?>
    <tr>
      <td width="154">CPF: </td>
      <td width="162"><b><?php echo mysql_result($r,$i,'a.cpf');?></b></td>
      <td width="91">RG: </td>
      <td><b><?php echo mysql_result($r,$i,'a.rgnumero');?></b></td>
      <td>ORGÃO EMISSOR  :</td>
      <td><b><?php echo mysql_result($r,$i,'a.rgorgaoemissor');?></b></td>
      <td>EMISSÃO :</td>
      <td width="164"><b><?php echo mysql_result($r,$i,'dtemissao');?></b> </td>
    </tr>
    <tr>
      <td>CERT. NASCIMENTO</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaonascimentonumero');?></b></td>
      <td>LIVRO</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaonascimentolivro');?></b></td>
      <td>FOLHA</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaonascimentofolha');?></b></td>
      <td>CIDADE</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaonascimentocidade');?></b></td>
    </tr>
    <tr>
      <td>SUB-DISTRITO</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaonascimentosubdistrito');?></b></td>
      <td>UF</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaonascimentouf');?></b></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>CERT. CASAMENTO</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaocasamentonumero');?></b></td>
      <td>LIVRO</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaocasamentolivro');?></b></td>
      <td>FOLHA</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaocasamentofolha');?></b></td>
      <td>CIDADE</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaocasamentocidade');?></b></td>
    </tr>
    <tr>
      <td>SUB-DISTRITO</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaocasamentosubdistrito');?></b></td>
      <td>UF</td>
      <td><b><?php echo mysql_result($r,$i,'a.certidaocasamentouf');?></b></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3">CERT. ALISTAMENTO MILITAR <b><?php echo mysql_result($r,$i,'a.certificado_alistamento_militar_numero');?></b></td>
      <td>SÉRIE</td>
      <td><b><?php echo mysql_result($r,$i,'a.certificado_alistamento_militar_serie');?></b></td>
      <td>RM</td>
      <td><b><?php echo mysql_result($r,$i,'a.certificado_alistamento_militar_rm');?></b></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>CSM</td>
      <td><b><?php echo mysql_result($r,$i,'a.certificado_alistamento_militar_csm');?></b></td>
      <td>DATA</td>
      <td><b><?php echo mysql_result($r,$i,'dtalistamento');?></b></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3">CERT. RESERVISTA <b><?php echo mysql_result($r,$i,'a.certificado_reservista_numero');?></b></td>
      <td>SÉRIE</td>
      <td><b><?php echo mysql_result($r,$i,'a.certificado_reservista_serie');?></b></td>
      <td>RM</td>
      <td><b><?php echo mysql_result($r,$i,'a.certificado_reservista_rm');?></b></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>CSM</td>
      <td><b><?php echo mysql_result($r,$i,'a.certificado_reservista_csm');?></b></td>
      <td>DATA</td>
      <td><b><?php echo mysql_result($r,$i,'dtcertreservista');?></b></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>TÍTULO DE ELEITOR </td>
      <td><b><?php echo mysql_result($r,$i,'a.titulo_eleitor_numero');?></b></td>
      <td>ZONA</td>
      <td><b><?php echo mysql_result($r,$i,'a.titulo_eleitor_zona');?></b></td>
      <td>SEÇÃO   </td>
      <td><b><?php echo mysql_result($r,$i,'a.titulo_eleitor_secao');?></b></td>
      <td>EMISSÃO</td>
      <td><b><?php echo mysql_result($r,$i,'dttitulo');?></b></td>
    </tr>
    <tr>
      <td colspan="2">CARTEIRA DE TRABALHO <b><?php echo mysql_result($r,$i,'a.carteira_trabalho');?></b></td>
      <td>&nbsp;</td>
      <td width="94">&nbsp;</td>
      <td width="141">&nbsp;</td>
      <td width="108">&nbsp;</td>
      <td width="109">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="8">&nbsp;</td>
    </tr>
    <tr> </tr>
  </tbody>
</table>
<br />
<table width="1059">
  <tbody>
    <?php for($i=0;$i<$ln2;$i++){?>
    <tr>
      <td width="105">MATRÍCULA: </td>
      <td width="77"><b><?php echo mysql_result($r2,$i,'ma.matricula_aluno');?></b></td>
      <td width="77">PONTOS :</td>
      <td width="77"><b><?php echo mysql_result($r2,$i,'ma.pontos_concursos');?></b></td>
      <td width="144">CLASSIFICAÇÃO :</td>
      <td width="77"><b><?php echo mysql_result($r2,$i,'ma.classificacao_concurso');?></b></td>
      <td width="181">DATA DA MATRÍCULA:</td>
      <td width="108"><b><?php echo mysql_result($r2,$i,'dtmatricula');?></b></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</body>
</html>	
  <?php
 /*ini_set('memory_limit','200M');
  $html = ob_get_clean();
	// pega o conteudo do buffer, insere na variavel e limpa a mem�ria
	 
	$html = utf8_encode($html);
	// converte o conteudo para uft-8
	
	
	define('MPDF_PATH', '../../classes/mpdf/');
	include(MPDF_PATH.'mpdf.php');
	// inclui a classe
	 
	$mpdf=new mPDF('pt','A4',3,'',15,15,16,16,9,9,'L'); 
	// cria o objeto
	$mpdf->AddPage('L'); 
	$mpdf->allow_charset_conversion=true;
	// permite a conversao (opcional)
	$mpdf->charset_in='UTF-8';
	// converte todo o PDF para utf-8
	 $mpdf->SetDisplayMode('fullpage');
	 // modo de visualiza��o
	 
	 $mpdf->SetFooter('{DATE j/m/Y  H:i}|{PAGENO}/{nb}|FAETERJ - DUQUE DE CAXIAS / SYSDUQUE');
	 //bacana este rodape, nao eh mesmo?
	$mpdf->WriteHTML($html);
	// escreve definitivamente o conteudo no PDF
	 
	$mpdf->Output();*/
	// imprime
	 
exit();
?>